"""
AURORA BRITANNIA — NPC System  (pedestrians + pursuers)
"""
import math
import random
import pygame
from utils.config import (
    NPC_WALK_SPEED, NPC_RUN_SPEED, NPC_RADIUS,
    WORLD_W, WORLD_H, TILE_SIZE,
    C_WHITE, C_RED, C_GREY, C_DARK_GREY,
    DEG2RAD, RAD2DEG,
)

STATE_WANDER  = 'wander'
STATE_FLEE    = 'flee'
STATE_PURSUE  = 'pursue'
STATE_IDLE    = 'idle'

_NPC_COLS = [
    (160, 180, 200),
    (180, 150, 120),
    (140, 190, 160),
    (200, 160, 140),
    (160, 160, 200),
]

_NEXT_NID = 0


def _nid():
    global _NEXT_NID
    _NEXT_NID += 1
    return _NEXT_NID


class NPC:
    """Lightweight pedestrian or pursuer NPC."""

    def __init__(self, wx: float, wy: float,
                 is_pursuer: bool = False, colour=None):
        self.nid         = _nid()
        self.x           = float(wx)
        self.y           = float(wy)
        self.angle       = random.uniform(0, 360)
        self.state       = STATE_PURSUE if is_pursuer else STATE_WANDER
        self.is_pursuer  = is_pursuer
        self.active      = True

        self.colour      = colour or random.choice(_NPC_COLS)
        if is_pursuer:
            self.colour  = (60, 80, 220)

        # Wander target
        self._wander_target = (wx, wy)
        self._wander_timer  = 0.0
        self._idle_timer    = 0.0

        # Speed
        self.base_speed     = NPC_WALK_SPEED if not is_pursuer else NPC_RUN_SPEED

        # Cached visible indicator
        self._blink_t       = random.uniform(0, 10)

    # ── update ──────────────────────────────────────────────────────────────

    def update(self, dt: float, player_x: float, player_y: float,
               heat: float, world_map):
        self._blink_t += dt
        dist_to_player = math.hypot(self.x - player_x, self.y - player_y)

        if self.is_pursuer:
            self._update_pursue(dt, player_x, player_y, world_map)
        else:
            # Determine state based on heat and proximity
            if heat > 50 and dist_to_player < 300:
                self.state = STATE_FLEE
            elif self.state == STATE_FLEE and dist_to_player > 500:
                self.state = STATE_WANDER
            elif self.state == STATE_FLEE and heat < 20:
                self.state = STATE_WANDER

            if self.state == STATE_WANDER:
                self._update_wander(dt, world_map)
            elif self.state == STATE_FLEE:
                self._update_flee(dt, player_x, player_y, world_map)
            elif self.state == STATE_IDLE:
                self._idle_timer -= dt
                if self._idle_timer <= 0:
                    self.state = STATE_WANDER

    def _update_wander(self, dt: float, world_map):
        self._wander_timer -= dt
        tx, ty = self._wander_target
        dx, dy = tx - self.x, ty - self.y
        dist   = math.hypot(dx, dy)

        if dist < 15 or self._wander_timer <= 0:
            self._pick_wander_target(world_map)
            # Occasionally idle
            if random.random() < 0.15:
                self.state       = STATE_IDLE
                self._idle_timer = random.uniform(1.0, 4.0)
            return

        speed = NPC_WALK_SPEED
        self._move_toward(tx, ty, speed, dt, world_map)

    def _update_flee(self, dt: float, px: float, py: float, world_map):
        # Move away from player
        dx, dy = self.x - px, self.y - py
        dist   = math.hypot(dx, dy)
        if dist < 1:
            dx, dy = 1, 0
        else:
            dx /= dist
            dy /= dist
        tx = self.x + dx * 300
        ty = self.y + dy * 300
        self._move_toward(tx, ty, NPC_RUN_SPEED, dt, world_map)

    def _update_pursue(self, dt: float, px: float, py: float, world_map):
        dist = math.hypot(px - self.x, py - self.y)
        if dist > 20:
            self._move_toward(px, py, NPC_RUN_SPEED, dt, world_map)

    def _move_toward(self, tx: float, ty: float, speed: float,
                     dt: float, world_map):
        dx, dy = tx - self.x, ty - self.y
        dist   = math.hypot(dx, dy)
        if dist < 1:
            return
        dx /= dist
        dy /= dist
        self.angle = math.atan2(dy, dx) * RAD2DEG

        nx = self.x + dx * speed * dt
        ny = self.y + dy * speed * dt

        # Slide collision
        if world_map.circle_clear(nx, self.y, NPC_RADIUS * 0.8):
            self.x = nx
        elif world_map.circle_clear(nx + dy * 12, self.y, NPC_RADIUS * 0.8):
            self.x = nx + dy * 12   # try slight nudge
        if world_map.circle_clear(self.x, ny, NPC_RADIUS * 0.8):
            self.y = ny
        elif world_map.circle_clear(self.x, ny - dx * 12, NPC_RADIUS * 0.8):
            self.y = ny - dx * 12

        # Clamp to world
        self.x = max(NPC_RADIUS, min(WORLD_W - NPC_RADIUS, self.x))
        self.y = max(NPC_RADIUS, min(WORLD_H - NPC_RADIUS, self.y))

    def _pick_wander_target(self, world_map):
        for _ in range(20):
            angle  = random.uniform(0, math.pi * 2)
            dist   = random.uniform(60, 250)
            tx     = self.x + math.cos(angle) * dist
            ty     = self.y + math.sin(angle) * dist
            tx     = max(0, min(WORLD_W - 1, tx))
            ty     = max(0, min(WORLD_H - 1, ty))
            if world_map.is_walkable(tx, ty):
                self._wander_target = (tx, ty)
                self._wander_timer  = random.uniform(3.0, 8.0)
                return
        self._wander_target = (self.x, self.y)
        self._wander_timer  = 2.0

    # ── rendering ───────────────────────────────────────────────────────────

    def render(self, surface: pygame.Surface, cam_x: float, cam_y: float):
        sx = int(self.x - cam_x)
        sy = int(self.y - cam_y)
        sw = surface.get_width()
        sh = surface.get_height()

        if sx < -20 or sx > sw + 20 or sy < -20 or sy > sh + 20:
            return

        r = NPC_RADIUS

        # Shadow
        pygame.draw.ellipse(surface, (0, 0, 0, 60),
                            (sx - r, sy + r - 3, r * 2, 5))

        # Body
        col = self.colour
        if self.is_pursuer:
            blink = (int(self._blink_t * 5) % 2 == 0)
            col   = (80, 100, 255) if blink else (40, 60, 200)

        pygame.draw.circle(surface, (20, 22, 35), (sx, sy), r + 1)
        pygame.draw.circle(surface, col, (sx, sy), r)

        # Direction dot
        rad = self.angle * DEG2RAD
        hx  = int(sx + math.cos(rad) * (r + 3))
        hy  = int(sy + math.sin(rad) * (r + 3))
        pygame.draw.circle(surface, (240, 240, 255), (hx, hy), 2)

        if self.is_pursuer:
            # "PURSUIT" marker
            pygame.draw.circle(surface, (0, 0, 0, 120), (sx, sy - r - 8), 6)
            pygame.draw.circle(surface, (80, 100, 255), (sx, sy - r - 8), 5)


class NPCSystem:
    """Manages all pedestrian NPCs and pursuers."""

    def __init__(self):
        self.pedestrians : list[NPC] = []
        self.pursuers    : list[NPC] = []

    def spawn_pedestrians(self, count: int, world_map, regions):
        """Spawn pedestrians distributed across regions."""
        self.pedestrians.clear()
        per_region = count // len(regions)
        for region in regions:
            spawned = 0
            attempts = 0
            while spawned < per_region and attempts < 500:
                attempts += 1
                wx = random.uniform(region.wx0, region.wx1)
                wy = random.uniform(region.wy0, region.wy1)
                if world_map.is_walkable(wx, wy):
                    npc = NPC(wx, wy)
                    npc._pick_wander_target(world_map)
                    self.pedestrians.append(npc)
                    spawned += 1

    def spawn_pursuer(self, wx: float, wy: float, world_map) -> NPC:
        """Spawn a pursuer NPC near (wx, wy) on a road tile."""
        best = world_map.nearest_road(wx, wy, 400)
        # Offset slightly so it doesn't spawn on top of player
        offset_angle = random.uniform(0, math.pi * 2)
        ox = best[0] + math.cos(offset_angle) * 60
        oy = best[1] + math.sin(offset_angle) * 60
        p  = NPC(ox, oy, is_pursuer=True)
        self.pursuers.append(p)
        return p

    def remove_excess_pursuers(self, max_count: int):
        while len(self.pursuers) > max_count:
            self.pursuers.pop(0)

    def clear_pursuers(self):
        self.pursuers.clear()

    def update(self, dt: float, px: float, py: float,
               heat: float, world_map):
        for npc in self.pedestrians:
            npc.update(dt, px, py, heat, world_map)
        for p in self.pursuers:
            p.update(dt, px, py, heat, world_map)

    def render(self, surface: pygame.Surface, cam_x: float, cam_y: float):
        for npc in self.pedestrians:
            npc.render(surface, cam_x, cam_y)
        for p in self.pursuers:
            p.render(surface, cam_x, cam_y)

    def pursuer_near_player(self, px: float, py: float, threshold=40) -> bool:
        for p in self.pursuers:
            if math.hypot(p.x - px, p.y - py) < threshold:
                return True
        return False
