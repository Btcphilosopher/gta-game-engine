"""
AURORA BRITANNIA — World Map  (tile generation + rendering)
"""
import random
import pygame
import numpy as np
from utils.config import (
    TILE_SIZE, MAP_W, MAP_H, WORLD_W, WORLD_H,
    SCREEN_W, SCREEN_H,
    TILE_ROAD, TILE_BUILDING, TILE_PAVEMENT, TILE_PARK,
    TILE_WATER, TILE_INDUSTRIAL, TILE_RAIL, SOLID_TILES,
    ZONE_SPLIT_X, ZONE_SPLIT_Y,
    C_ROAD, C_ROAD_MARK, C_PAVEMENT, C_PARK, C_WATER, C_RAIL, C_RAIL_MARK,
    C_BUILDING_CITY, C_BUILDING_CITY2, C_BUILDING_IND, C_INDUSTRIAL,
    C_BUILDING_OUT, C_BG,
)

# Road grid parameters
MAJOR_ROAD_INTERVAL = 10     # major road every N tiles
MAJOR_ROAD_WIDTH    = 2      # tiles

RNG = random.Random(42)      # deterministic map


def _zone(tx, ty):
    if tx < ZONE_SPLIT_X and ty < ZONE_SPLIT_Y:   return 'city'
    if tx >= ZONE_SPLIT_X and ty < ZONE_SPLIT_Y:  return 'industrial'
    if tx >= ZONE_SPLIT_X and ty >= ZONE_SPLIT_Y: return 'transport'
    return 'outskirts'


def _is_major_road(tx, ty):
    return (tx % MAJOR_ROAD_INTERVAL < MAJOR_ROAD_WIDTH or
            ty % MAJOR_ROAD_INTERVAL < MAJOR_ROAD_WIDTH)


def _is_minor_road(tx, ty, zone):
    """City has denser minor roads every 5 tiles."""
    if zone != 'city':
        return False
    # single-tile minor roads on the 5-tile sub-grid (but not where major road already is)
    lx = tx % MAJOR_ROAD_INTERVAL
    ly = ty % MAJOR_ROAD_INTERVAL
    return (lx == 5 or ly == 5) and not _is_major_road(tx, ty)


def _adjacent_to_road(tx, ty, tiles):
    """True if any 8-neighbour is a road tile (value 0 = TILE_ROAD)."""
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            if dx == 0 and dy == 0:
                continue
            nx, ny = tx + dx, ty + dy
            if 0 <= nx < MAP_W and 0 <= ny < MAP_H:
                v = tiles[ny, nx]
                if v == TILE_ROAD and v != _UNSET:
                    return True
    return False


def _classify(tx, ty):
    zone = _zone(tx, ty)
    if _is_major_road(tx, ty):
        return TILE_ROAD
    if _is_minor_road(tx, ty, zone):
        return TILE_ROAD
    # Transport hub rail lines
    if zone == 'transport':
        ly = ty % MAJOR_ROAD_INTERVAL
        if ly in (4, 5, 6) and not _is_major_road(tx, ty):
            lx = tx % MAJOR_ROAD_INTERVAL
            if lx not in (0, 1):
                return TILE_RAIL
    # Water strip in transport/outskirts border
    if zone == 'outskirts' and 52 <= ty <= 54:
        lx = tx % MAJOR_ROAD_INTERVAL
        if lx not in (0, 1):
            return TILE_WATER
    return None   # deferred — needs neighbour info


_UNSET = 255   # sentinel for unprocessed tiles


def _generate_tiles():
    tiles = np.full((MAP_H, MAP_W), _UNSET, dtype=np.uint8)

    # First pass: roads and rails
    for ty in range(MAP_H):
        for tx in range(MAP_W):
            result = _classify(tx, ty)
            if result is not None:
                tiles[ty, tx] = result

    # Second pass: pavement adjacent to roads; then fill zones
    for ty in range(MAP_H):
        for tx in range(MAP_W):
            if tiles[ty, tx] != _UNSET:   # already set
                continue
            zone = _zone(tx, ty)
            adj = _adjacent_to_road(tx, ty, tiles)
            if adj:
                tiles[ty, tx] = TILE_PAVEMENT
                continue

            # Interior of blocks — zone-specific
            if zone == 'city':
                # Occasionally a park block
                bx, by = tx // MAJOR_ROAD_INTERVAL, ty // MAJOR_ROAD_INTERVAL
                seed = (bx * 31 + by * 17) % 100
                if seed < 8:
                    tiles[ty, tx] = TILE_PARK
                else:
                    tiles[ty, tx] = TILE_BUILDING

            elif zone == 'industrial':
                bx, by = tx // MAJOR_ROAD_INTERVAL, ty // MAJOR_ROAD_INTERVAL
                seed = (bx * 13 + by * 29) % 100
                if seed < 15:
                    tiles[ty, tx] = TILE_PARK    # yard/open area
                else:
                    tiles[ty, tx] = TILE_INDUSTRIAL

            elif zone == 'transport':
                tiles[ty, tx] = TILE_PAVEMENT   # open depot yards

            elif zone == 'outskirts':
                bx, by = tx // MAJOR_ROAD_INTERVAL, ty // MAJOR_ROAD_INTERVAL
                seed = (bx * 7 + by * 41) % 100
                if seed < 35:
                    tiles[ty, tx] = TILE_PARK
                elif seed < 65:
                    tiles[ty, tx] = TILE_BUILDING
                else:
                    tiles[ty, tx] = TILE_PAVEMENT

    return tiles


# Colour lookup per tile type
_TILE_COL = {
    TILE_ROAD:       C_ROAD,
    TILE_BUILDING:   C_BUILDING_CITY,
    TILE_PAVEMENT:   C_PAVEMENT,
    TILE_PARK:       C_PARK,
    TILE_WATER:      C_WATER,
    TILE_INDUSTRIAL: C_INDUSTRIAL,
    TILE_RAIL:       C_RAIL,
}


class WorldMap:
    """Holds the tile grid and handles rendering."""

    def __init__(self):
        self.tiles  = _generate_tiles()
        self._cache_surface = None
        self._build_static_surface()

    # ── internal surface ────────────────────────────────────────────────────

    def _build_static_surface(self):
        """Pre-render the entire map to a large surface; blit a viewport each frame."""
        surf = pygame.Surface((WORLD_W, WORLD_H))
        surf.fill(C_BG)
        for ty in range(MAP_H):
            for tx in range(MAP_W):
                t  = self.tiles[ty, tx]
                col= self._tile_col(tx, ty, t)
                rx = tx * TILE_SIZE
                ry = ty * TILE_SIZE
                pygame.draw.rect(surf, col, (rx, ry, TILE_SIZE, TILE_SIZE))
                # Road markings
                if t == TILE_ROAD:
                    self._draw_road_detail(surf, tx, ty, rx, ry)
                elif t == TILE_RAIL:
                    self._draw_rail_detail(surf, tx, ty, rx, ry)
        self._cache_surface = surf

    def _tile_col(self, tx, ty, t):
        if t == TILE_BUILDING:
            # Alternate two shades for visual variety
            bx, by = tx // MAJOR_ROAD_INTERVAL, ty // MAJOR_ROAD_INTERVAL
            return C_BUILDING_CITY if (bx + by) % 2 == 0 else C_BUILDING_CITY2
        return _TILE_COL.get(t, C_BG)

    @staticmethod
    def _draw_road_detail(surf, tx, ty, rx, ry):
        """Centre-line dashes and lane markings."""
        # Centre dashes on major horizontal roads
        if ty % MAJOR_ROAD_INTERVAL == 0:
            cx = rx + TILE_SIZE // 2
            if tx % 4 < 2:
                pygame.draw.line(surf, C_ROAD_MARK,
                                 (rx + 2, ry + TILE_SIZE // 2),
                                 (rx + TILE_SIZE - 2, ry + TILE_SIZE // 2), 1)
        if tx % MAJOR_ROAD_INTERVAL == 0:
            cy = ry + TILE_SIZE // 2
            if ty % 4 < 2:
                pygame.draw.line(surf, C_ROAD_MARK,
                                 (rx + TILE_SIZE // 2, ry + 2),
                                 (rx + TILE_SIZE // 2, ry + TILE_SIZE - 2), 1)

    @staticmethod
    def _draw_rail_detail(surf, tx, ty, rx, ry):
        col = C_RAIL_MARK
        pygame.draw.line(surf, col, (rx, ry + 4), (rx + TILE_SIZE, ry + 4), 1)
        pygame.draw.line(surf, col, (rx, ry + TILE_SIZE - 4),
                         (rx + TILE_SIZE, ry + TILE_SIZE - 4), 1)
        if tx % 3 == 0:
            pygame.draw.line(surf, col, (rx + TILE_SIZE // 2, ry),
                             (rx + TILE_SIZE // 2, ry + TILE_SIZE), 2)

    # ── public API ──────────────────────────────────────────────────────────

    def get_tile_t(self, tx: int, ty: int) -> int:
        """Get tile type by tile coords (clamped)."""
        tx = max(0, min(MAP_W - 1, tx))
        ty = max(0, min(MAP_H - 1, ty))
        return int(self.tiles[ty, tx])

    def get_tile(self, wx: float, wy: float) -> int:
        """Get tile type from world pixel position."""
        return self.get_tile_t(int(wx / TILE_SIZE), int(wy / TILE_SIZE))

    def is_solid(self, wx: float, wy: float) -> bool:
        return self.get_tile(wx, wy) in SOLID_TILES

    def is_walkable(self, wx: float, wy: float) -> bool:
        return not self.is_solid(wx, wy)

    def circle_clear(self, wx: float, wy: float, r: float) -> bool:
        """True if a circle centred at (wx,wy) with radius r is unobstructed."""
        offsets = [(0, 0), (r, 0), (-r, 0), (0, r), (0, -r),
                   (r * 0.7, r * 0.7), (-r * 0.7, r * 0.7),
                   (r * 0.7, -r * 0.7), (-r * 0.7, -r * 0.7)]
        for dx, dy in offsets:
            if self.is_solid(wx + dx, wy + dy):
                return False
        return True

    def clamp_world(self, wx, wy):
        """Clamp world coordinates to within map bounds."""
        return (max(0.0, min(float(WORLD_W - 1), wx)),
                max(0.0, min(float(WORLD_H - 1), wy)))

    def nearest_road(self, wx, wy, search_r=300):
        """Return world pos of nearest road tile to (wx, wy)."""
        tx0 = int(wx / TILE_SIZE)
        ty0 = int(wy / TILE_SIZE)
        sr  = int(search_r / TILE_SIZE) + 1
        best_dist = float('inf')
        best = (wx, wy)
        for dy in range(-sr, sr + 1):
            for dx in range(-sr, sr + 1):
                tx, ty = tx0 + dx, ty0 + dy
                if 0 <= tx < MAP_W and 0 <= ty < MAP_H:
                    if self.tiles[ty, tx] == TILE_ROAD:
                        d = dx * dx + dy * dy
                        if d < best_dist:
                            best_dist = d
                            best = (tx * TILE_SIZE + TILE_SIZE // 2,
                                    ty * TILE_SIZE + TILE_SIZE // 2)
        return best

    # ── rendering ───────────────────────────────────────────────────────────

    def render(self, surface: pygame.Surface, cam_x: float, cam_y: float):
        """Blit the visible portion of the pre-rendered map onto surface."""
        src_rect = pygame.Rect(int(cam_x), int(cam_y), SCREEN_W, SCREEN_H)
        surface.blit(self._cache_surface, (0, 0), src_rect)

    def world_to_screen(self, wx, wy, cam_x, cam_y):
        return (int(wx - cam_x), int(wy - cam_y))
