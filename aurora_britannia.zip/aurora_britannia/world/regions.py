"""
AURORA BRITANNIA — World Regions & Zone System
"""
import random
from utils.config import (
    TILE_SIZE, ZONE_SPLIT_X, ZONE_SPLIT_Y,
    MAP_W, MAP_H, WORLD_W, WORLD_H,
    FACTION_NAMES, FACTION_COLS,
    CRIME_DRIFT_RATE, FACTION_SPREAD_RATE,
)


class Region:
    """Represents a named zone with economic, crime and faction properties."""

    def __init__(self, name, tx0, ty0, tx1, ty1, zone_type,
                 base_crime=0.2, activity=0.5, dominant_faction=0):
        self.name            = name
        self.zone_type       = zone_type   # 'city','industrial','transport','outskirts'

        # Tile bounds (inclusive)
        self.tx0, self.ty0   = tx0, ty0
        self.tx1, self.ty1   = tx1, ty1

        # World pixel bounds
        self.wx0 = tx0 * TILE_SIZE
        self.wy0 = ty0 * TILE_SIZE
        self.wx1 = tx1 * TILE_SIZE
        self.wy1 = ty1 * TILE_SIZE
        self.w   = self.wx1 - self.wx0
        self.h   = self.wy1 - self.wy0

        # Simulation state
        self.crime_level     = base_crime          # 0.0–1.0
        self.activity_density= activity
        self.wealth          = 1000 + random.randint(-200, 400)

        # Faction influence: dict {faction_idx: 0.0–1.0}
        self.faction_influence = {i: 0.05 for i in range(4)}
        self.faction_influence[dominant_faction] = 0.6
        self._normalise_influence()

        # Restricted zone flag (high-security — triggers heat)
        self.restricted = (zone_type == 'industrial' and dominant_faction == 1)

    # ── helpers ──────────────────────────────────────────────────────────────

    def _normalise_influence(self):
        total = sum(self.faction_influence.values())
        if total > 0:
            for k in self.faction_influence:
                self.faction_influence[k] /= total

    def contains_world(self, wx, wy) -> bool:
        return self.wx0 <= wx < self.wx1 and self.wy0 <= wy < self.wy1

    def contains_tile(self, tx, ty) -> bool:
        return self.tx0 <= tx < self.tx1 and self.ty0 <= ty < self.ty1

    def dominant_faction(self) -> int:
        return max(self.faction_influence, key=lambda k: self.faction_influence[k])

    def dominant_colour(self):
        return FACTION_COLS[self.dominant_faction()]

    def centre_world(self):
        return ((self.wx0 + self.wx1) // 2, (self.wy0 + self.wy1) // 2)

    def random_road_point(self, world_map):
        """Return a random world-position that sits on a road tile in this region."""
        for _ in range(200):
            tx = random.randint(self.tx0, self.tx1 - 1)
            ty = random.randint(self.ty0, self.ty1 - 1)
            if world_map.get_tile_t(tx, ty) == 0:   # TILE_ROAD
                wx = tx * TILE_SIZE + TILE_SIZE // 2
                wy = ty * TILE_SIZE + TILE_SIZE // 2
                return (float(wx), float(wy))
        return self.centre_world()

    # ── simulation ───────────────────────────────────────────────────────────

    def update(self, dt: float, player_in_region: bool):
        # Crime drifts toward base level
        target = 0.3 if player_in_region else 0.2
        self.crime_level += (target - self.crime_level) * CRIME_DRIFT_RATE * dt
        self.crime_level  = max(0.0, min(1.0, self.crime_level))

        # Wealth slowly recovers
        self.wealth += (1000 - self.wealth) * 0.001 * dt

    def shift_faction(self, faction_idx: int, delta: float):
        self.faction_influence[faction_idx] = max(
            0.0, self.faction_influence[faction_idx] + delta)
        self._normalise_influence()

    def spread_faction(self, dt: float):
        dominant = self.dominant_faction()
        delta = FACTION_SPREAD_RATE * dt
        self.faction_influence[dominant] = min(
            1.0, self.faction_influence[dominant] + delta)
        self._normalise_influence()

    # ── display info ─────────────────────────────────────────────────────────

    def status_lines(self):
        dom = self.dominant_faction()
        return [
            f"{self.name}",
            f"ZONE    {self.zone_type.upper()}",
            f"CRIME   {self.crime_level*100:.0f}%",
            f"CONTROL {FACTION_NAMES[dom][:14]}",
            f"WEALTH  £{int(self.wealth):,}",
        ]


# ── Region registry ──────────────────────────────────────────────────────────

def build_regions() -> list:
    """Return the four canonical game regions."""
    return [
        Region(
            name="CITY CENTRE",
            tx0=0,           ty0=0,
            tx1=ZONE_SPLIT_X, ty1=ZONE_SPLIT_Y,
            zone_type="city",
            base_crime=0.25, activity=0.9, dominant_faction=0,
        ),
        Region(
            name="INDUSTRIAL CORRIDOR",
            tx0=ZONE_SPLIT_X, ty0=0,
            tx1=MAP_W,         ty1=ZONE_SPLIT_Y,
            zone_type="industrial",
            base_crime=0.45, activity=0.6, dominant_faction=1,
        ),
        Region(
            name="TRANSPORT HUB",
            tx0=ZONE_SPLIT_X, ty0=ZONE_SPLIT_Y,
            tx1=MAP_W,         ty1=MAP_H,
            zone_type="transport",
            base_crime=0.30, activity=0.7, dominant_faction=2,
        ),
        Region(
            name="OUTSKIRTS",
            tx0=0,            ty0=ZONE_SPLIT_Y,
            tx1=ZONE_SPLIT_X, ty1=MAP_H,
            zone_type="outskirts",
            base_crime=0.15, activity=0.3, dominant_faction=3,
        ),
    ]


def get_region_at(regions: list, wx: float, wy: float):
    """Return the Region containing world position (wx, wy), or None."""
    for r in regions:
        if r.contains_world(wx, wy):
            return r
    return None
