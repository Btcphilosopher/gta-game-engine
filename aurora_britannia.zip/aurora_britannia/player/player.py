"""
AURORA BRITANNIA — Player System
"""
import math
import pygame
from utils.config import (
    PLAYER_SPEED, PLAYER_RADIUS, PLAYER_INTERACT,
    PLAYER_SPAWN, WORLD_W, WORLD_H,
    C_CYAN, C_GOLD, C_WHITE, C_RED,
    DEG2RAD, RAD2DEG,
)

STATE_FOOT    = 'on_foot'
STATE_VEHICLE = 'in_vehicle'


class Player:
    def __init__(self):
        self.x, self.y   = float(PLAYER_SPAWN[0]), float(PLAYER_SPAWN[1])
        self.angle        = 0.0        # facing angle (degrees)
        self.speed        = 0.0
        self.state        = STATE_FOOT
        self.vehicle      = None       # current Vehicle if driving

        # Stats
        self.cash         = 2500
        self.heat         = 0.0        # 0–100 (managed by CrimeSystem)
        self.alive        = True

        # Interaction cooldown
        self._interact_cd = 0.0

        # For heat — track last trigger position
        self.speeding     = False

        # Visual — animated blink for heat
        self._blink_t     = 0.0

    # ── properties ──────────────────────────────────────────────────────────

    @property
    def pos(self):
        return (self.x, self.y)

    @property
    def world_rect(self):
        r = PLAYER_RADIUS
        return pygame.Rect(self.x - r, self.y - r, r * 2, r * 2)

    def distance_to(self, wx, wy):
        return math.hypot(wx - self.x, wy - self.y)

    def in_vehicle(self):
        return self.state == STATE_VEHICLE

    # ── update ──────────────────────────────────────────────────────────────

    def update(self, keys, dt: float, world_map, vehicles: list):
        self._interact_cd = max(0.0, self._interact_cd - dt)
        self._blink_t    += dt

        if self.state == STATE_FOOT:
            self._update_foot(keys, dt, world_map)
            # Check vehicle entry via E key
            if keys[pygame.K_e] and self._interact_cd <= 0:
                self._try_enter_vehicle(vehicles)

        elif self.state == STATE_VEHICLE:
            self.vehicle.driven_update(keys, dt, world_map)
            self.x = self.vehicle.x
            self.y = self.vehicle.y
            self.angle = self.vehicle.angle
            self.speeding = abs(self.vehicle.speed) > self.vehicle.max_speed * 0.75
            # Exit via E
            if keys[pygame.K_e] and self._interact_cd <= 0:
                self._exit_vehicle(world_map)

        # Clamp to world
        self.x = max(PLAYER_RADIUS, min(WORLD_W - PLAYER_RADIUS, self.x))
        self.y = max(PLAYER_RADIUS, min(WORLD_H - PLAYER_RADIUS, self.y))

    def _update_foot(self, keys, dt: float, world_map):
        dx = dy = 0
        if keys[pygame.K_w] or keys[pygame.K_UP]:    dy -= 1
        if keys[pygame.K_s] or keys[pygame.K_DOWN]:  dy += 1
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:  dx -= 1
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]: dx += 1

        if dx != 0 or dy != 0:
            length = math.hypot(dx, dy)
            dx /= length
            dy /= length
            self.angle = math.atan2(dy, dx) * RAD2DEG

        nx = self.x + dx * PLAYER_SPEED * dt
        ny = self.y + dy * PLAYER_SPEED * dt

        # Slide-along-wall collision
        if world_map.circle_clear(nx, self.y, PLAYER_RADIUS * 0.9):
            self.x = nx
        if world_map.circle_clear(self.x, ny, PLAYER_RADIUS * 0.9):
            self.y = ny

        self.speeding = False

    def _try_enter_vehicle(self, vehicles):
        nearest  = None
        best_d   = PLAYER_INTERACT
        for v in vehicles:
            if v.driver is None and v.active:
                d = self.distance_to(v.x, v.y)
                if d < best_d:
                    best_d  = d
                    nearest = v
        if nearest:
            self._enter_vehicle(nearest)

    def _enter_vehicle(self, vehicle):
        vehicle.driver = self
        self.vehicle   = vehicle
        self.state     = STATE_VEHICLE
        self._interact_cd = 0.4

    def _exit_vehicle(self, world_map):
        if self.vehicle:
            # Try to place player beside vehicle
            r   = DEG2RAD * self.vehicle.angle
            offsets = [
                (-math.sin(r) * 40, math.cos(r) * 40),
                (math.sin(r) * 40, -math.cos(r) * 40),
                (-math.cos(r) * 40, -math.sin(r) * 40),
                (math.cos(r) * 40, math.sin(r) * 40),
            ]
            placed = False
            for ox, oy in offsets:
                ex, ey = self.vehicle.x + ox, self.vehicle.y + oy
                if world_map.circle_clear(ex, ey, PLAYER_RADIUS):
                    self.x, self.y = ex, ey
                    placed = True
                    break
            if not placed:
                self.x, self.y = self.vehicle.x, self.vehicle.y

            self.vehicle.driver = None
            self.vehicle         = None
            self.state           = STATE_FOOT
            self._interact_cd    = 0.5
            self.speeding        = False

    # ── rewards / penalties ─────────────────────────────────────────────────

    def award(self, amount: int):
        self.cash += amount

    def penalise(self, amount: int):
        self.cash = max(0, self.cash - amount)

    # ── rendering ───────────────────────────────────────────────────────────

    def render(self, surface: pygame.Surface, cam_x: float, cam_y: float,
               font_sm: pygame.font.Font, show_nearby_vehicle=None):
        if self.state == STATE_VEHICLE:
            # Vehicle renders itself; just draw a driver indicator
            sx = int(self.x - cam_x)
            sy = int(self.y - cam_y)
            return

        sx = int(self.x - cam_x)
        sy = int(self.y - cam_y)

        # Shadow
        pygame.draw.ellipse(surface, (0, 0, 0, 80),
                            (sx - 10, sy + PLAYER_RADIUS - 4, 20, 8))

        # Body
        blink_on = (int(self._blink_t * 8) % 2 == 0) and self.heat > 60
        col = C_RED if blink_on else C_CYAN

        # Direction indicator line
        rad = self.angle * DEG2RAD
        ex  = sx + math.cos(rad) * (PLAYER_RADIUS + 5)
        ey  = sy + math.sin(rad) * (PLAYER_RADIUS + 5)
        pygame.draw.line(surface, col, (sx, sy), (int(ex), int(ey)), 2)

        # Body circle
        pygame.draw.circle(surface, (20, 30, 50), (sx, sy), PLAYER_RADIUS + 1)
        pygame.draw.circle(surface, col, (sx, sy), PLAYER_RADIUS)
        pygame.draw.circle(surface, C_WHITE, (sx, sy), 3)

        # Nearby vehicle hint
        if show_nearby_vehicle:
            show_nearby_vehicle.render_enter_hint(surface, cam_x, cam_y, font_sm)

    def render_screen_marker(self, surface: pygame.Surface):
        """HUD-space marker always showing player direction."""
        cx, cy = surface.get_width() // 2, surface.get_height() // 2
        pygame.draw.circle(surface, C_CYAN, (cx, cy), 5)
