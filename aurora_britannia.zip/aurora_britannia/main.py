"""
AURORA BRITANNIA: SYSTEMIC OPEN WORLD ENGINE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  python main.py

Controls
  WASD / Arrow keys  — Move / Drive
  E                  — Enter / Exit vehicle
  TAB                — Toggle faction overlay
  M                  — Generate new mission
  ESC                — Quit
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
import sys
import os

# Ensure the project root is on the path regardless of cwd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.game_loop import GameLoop


def main():
    loop = GameLoop()
    loop.run()


if __name__ == "__main__":
    main()
