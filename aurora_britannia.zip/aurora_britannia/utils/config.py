"""
AURORA BRITANNIA — Configuration Constants
"""
import math

# ── Screen ────────────────────────────────────────────────────────────────────
SCREEN_W       = 1280
SCREEN_H       = 720
FPS            = 60
TITLE          = "AURORA BRITANNIA  //  SYSTEMIC OPEN WORLD ENGINE"

# ── World / Map ───────────────────────────────────────────────────────────────
TILE_SIZE      = 40
MAP_W          = 120          # tiles wide
MAP_H          = 90           # tiles tall
WORLD_W        = MAP_W * TILE_SIZE   # 4800 px
WORLD_H        = MAP_H * TILE_SIZE   # 3600 px

# Zone boundaries (in tile coordinates)
ZONE_SPLIT_X   = 60           # left = city/outskirts, right = industrial/transport
ZONE_SPLIT_Y   = 45           # top  = city/industrial, bottom = outskirts/transport

# ── Tile Types ────────────────────────────────────────────────────────────────
TILE_ROAD        = 0
TILE_BUILDING    = 1
TILE_PAVEMENT    = 2
TILE_PARK        = 3
TILE_WATER       = 4
TILE_INDUSTRIAL  = 5
TILE_RAIL        = 6

SOLID_TILES = {TILE_BUILDING, TILE_INDUSTRIAL, TILE_WATER}

# ── Colours — Anglo-Futurist Dark Palette ────────────────────────────────────
C_BG            = (7,   8,  14)
C_ROAD          = (18,  20,  32)
C_ROAD_MARK     = (38,  40,  60)
C_PAVEMENT      = (26,  28,  42)
C_BUILDING_CITY = (14,  22,  48)
C_BUILDING_CITY2= (18,  30,  60)
C_BUILDING_IND  = (38,  26,  16)
C_INDUSTRIAL    = (44,  32,  20)
C_BUILDING_OUT  = (20,  34,  22)
C_PARK          = (14,  44,  18)
C_WATER         = (8,   32,  64)
C_RAIL          = (50,  44,  28)
C_RAIL_MARK     = (70,  62,  38)

C_GOLD          = (201, 162,  39)
C_GOLD_DIM      = (120,  96,  22)
C_CYAN          = (0,   212, 255)
C_CYAN_DIM      = (0,   110, 140)
C_RED           = (255,  45,  45)
C_RED_DIM       = (140,  25,  25)
C_GREEN         = (0,   210,  90)
C_GREEN_DIM     = (0,   110,  45)
C_ORANGE        = (255, 140,   0)
C_WHITE         = (210, 215, 235)
C_GREY          = (75,   80, 100)
C_DARK_GREY     = (35,   38,  52)

# Faction colours
FACTION_COLS = [
    (201, 162,  39),   # 0 Crown Syndicate    — gold
    (220,  60,  40),   # 1 Iron Collective     — red-orange
    (0,   200, 255),   # 2 Free Operators      — cyan
    (100, 210,  70),   # 3 Municipal Order     — green
]
FACTION_NAMES = [
    "CROWN SYNDICATE",
    "IRON COLLECTIVE",
    "FREE OPERATORS",
    "MUNICIPAL ORDER",
]

# ── UI ────────────────────────────────────────────────────────────────────────
MINIMAP_SIZE    = 200
MINIMAP_MARGIN  = 12
MINIMAP_SCALE   = MINIMAP_SIZE / max(WORLD_W, WORLD_H)   # world→minimap
FONT_SM         = 13
FONT_MD         = 16
FONT_LG         = 22
FONT_XL         = 32

# ── Player ────────────────────────────────────────────────────────────────────
PLAYER_SPEED    = 210    # px/s on foot
PLAYER_RADIUS   = 9
PLAYER_INTERACT = 60     # interaction range

# ── Vehicles ──────────────────────────────────────────────────────────────────
# (max_speed, accel, brake, friction, turn_speed, width, height, colour)
VEHICLE_TYPES = {
    "CAR": dict(
        max_speed=380, accel=260, brake=380, friction=140,
        turn_speed=88,  width=28, height=16, durability=100,
        colour=(80, 160, 240),
    ),
    "SPORTS": dict(
        max_speed=520, accel=360, brake=300, friction=100,
        turn_speed=100, width=26, height=14, durability=70,
        colour=(240, 80,  80),
    ),
    "VAN": dict(
        max_speed=260, accel=160, brake=340, friction=160,
        turn_speed=64,  width=34, height=20, durability=160,
        colour=(160, 200, 100),
    ),
    "PURSUIT": dict(
        max_speed=430, accel=300, brake=360, friction=130,
        turn_speed=92,  width=30, height=16, durability=120,
        colour=(60,  80, 200),
    ),
}

# ── NPCs ──────────────────────────────────────────────────────────────────────
NPC_WALK_SPEED  = 58
NPC_RUN_SPEED   = 140
NPC_RADIUS      = 7
NPC_COUNT       = 32
NPC_PURSUE_DIST = 600    # distance within which pursuers chase

# ── Crime / Heat ──────────────────────────────────────────────────────────────
MAX_HEAT        = 100
HEAT_DECAY_IDLE = 3.0    # per second when calm
HEAT_DECAY_MOVING=1.2    # per second when moving but no trigger
HEAT_SPEEDING   = 0.8    # per second while speeding on road
HEAT_ZONE_TRIG  = 8.0    # on entering a hot zone
HEAT_MISSION    = 12.0   # on flagged mission action
PURSUIT_HEAT_THRESHOLD = 30   # heat above this spawns pursuers
MAX_PURSUERS    = 6

# ── Economy ───────────────────────────────────────────────────────────────────
ECONOMY_TICK    = 5.0    # seconds between economy updates
BASE_WEALTH     = 1000

# ── Missions ─────────────────────────────────────────────────────────────────
MISSION_TYPES   = ["DELIVERY", "EVADE", "REACH_TARGET", "RETRIEVE", "ESCORT"]
MISSION_REWARD  = {"DELIVERY":800,"EVADE":600,"REACH_TARGET":500,"RETRIEVE":1000,"ESCORT":900}
MISSION_TIME    = {"DELIVERY":90, "EVADE":60, "REACH_TARGET":75, "RETRIEVE":100,"ESCORT":110}
MISSION_GEN_INTERVAL = 30.0   # seconds between auto-generation attempts

# ── World Simulation ──────────────────────────────────────────────────────────
FACTION_SPREAD_RATE = 0.002   # per second
CRIME_DRIFT_RATE    = 0.01    # per second natural drift toward 0.3

# ── Spawn ─────────────────────────────────────────────────────────────────────
PLAYER_SPAWN    = (820.0, 820.0)   # world px — city centre

# ── Math helpers ──────────────────────────────────────────────────────────────
DEG2RAD         = math.pi / 180.0
RAD2DEG         = 180.0 / math.pi
