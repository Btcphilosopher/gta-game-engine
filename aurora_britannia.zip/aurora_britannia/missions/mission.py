"""
AURORA BRITANNIA — Mission Data Structures
"""
import math
from utils.config import MISSION_REWARD, MISSION_TIME, C_GOLD, C_CYAN, C_RED, C_GREEN, C_ORANGE

STATUS_ACTIVE    = 'active'
STATUS_COMPLETE  = 'complete'
STATUS_FAILED    = 'failed'
STATUS_AVAILABLE = 'available'

# Objective markers
MARKER_COLOURS = {
    'DELIVERY':     C_GOLD,
    'EVADE':        C_RED,
    'REACH_TARGET': C_CYAN,
    'RETRIEVE':     C_ORANGE,
    'ESCORT':       C_GREEN,
}


class Mission:
    """
    A single dynamically generated mission.

    target_pos   — primary world objective position
    start_pos    — where the mission was accepted / started
    giver_faction— which faction benefits from completion
    """

    _MID = 0

    def __init__(self, mtype: str, target_pos: tuple,
                 start_pos: tuple, region_name: str,
                 giver_faction: int = 0,
                 reward_mult: float = 1.0):
        Mission._MID += 1
        self.mid          = Mission._MID
        self.mtype        = mtype
        self.target_pos   = target_pos
        self.start_pos    = start_pos
        self.region_name  = region_name
        self.giver_faction= giver_faction
        self.status       = STATUS_ACTIVE
        self.time_limit   = MISSION_TIME.get(mtype, 90) * reward_mult
        self.time_left    = self.time_limit
        self.reward       = int(MISSION_REWARD.get(mtype, 500) * reward_mult)

        # Evade mission — destination to reach while evading
        self.evade_target = None
        # Escort NPC id
        self.escort_npc   = None

        # Subphase for multi-step missions (e.g. RETRIEVE: first go to pickup, then deliver)
        self.phase        = 0
        self.phase_target = None   # secondary target for phase 2

        self._description = self._build_description()

    def _build_description(self):
        tx, ty = int(self.target_pos[0]), int(self.target_pos[1])
        desc   = {
            'DELIVERY':
                f"DELIVER PACKAGE — {self.region_name}\n"
                f"Drive to the marked location before time expires.",
            'EVADE':
                f"EVADE PURSUIT — {self.region_name}\n"
                f"Reach the safe zone while avoiding all pursuit.",
            'REACH_TARGET':
                f"REACH TARGET — {self.region_name}\n"
                f"Get to the objective point as fast as possible.",
            'RETRIEVE':
                f"RETRIEVE ASSET — {self.region_name}\n"
                f"Collect the package, then deliver it to safety.",
            'ESCORT':
                f"ESCORT OPERATIVE — {self.region_name}\n"
                f"Protect the operative and reach the extraction point.",
        }
        return desc.get(self.mtype, f"OBJECTIVE — {self.region_name}")

    @property
    def description(self):
        if self.mtype == 'RETRIEVE' and self.phase == 1:
            return f"DELIVER RETRIEVED ASSET — {self.region_name}\nGet to the drop-off point."
        return self._description

    @property
    def active_target(self):
        if self.mtype == 'RETRIEVE' and self.phase == 1 and self.phase_target:
            return self.phase_target
        return self.target_pos

    @property
    def colour(self):
        return MARKER_COLOURS.get(self.mtype, C_CYAN)

    def distance_to_target(self, px, py):
        tx, ty = self.active_target
        return math.hypot(tx - px, ty - py)

    def update(self, dt: float) -> str:
        """Tick the mission timer. Returns 'failed', 'active', or 'complete'."""
        if self.status != STATUS_ACTIVE:
            return self.status
        self.time_left -= dt
        if self.time_left <= 0:
            self.status = STATUS_FAILED
        return self.status

    def complete(self):
        self.status = STATUS_COMPLETE

    def fail(self):
        self.status = STATUS_FAILED

    def is_active(self):
        return self.status == STATUS_ACTIVE

    def hud_lines(self):
        mins  = int(self.time_left // 60)
        secs  = int(self.time_left % 60)
        phase_str = f"  PHASE {self.phase + 1}/2" if self.mtype == 'RETRIEVE' else ""
        return [
            f"▶ {self.mtype}{phase_str}",
            f"  {self.region_name}",
            f"  TIME  {mins:02d}:{secs:02d}",
            f"  PAY   £{self.reward:,}",
        ]

    def completion_summary(self):
        return {
            'type':    self.mtype,
            'reward':  self.reward,
            'region':  self.region_name,
            'faction': self.giver_faction,
            'status':  self.status,
        }
