"""
AURORA BRITANNIA — Mission Generator
"""
import random
import math
import pygame
from utils.config import (
    MISSION_TYPES, MISSION_GEN_INTERVAL, TILE_SIZE,
    C_GOLD, C_CYAN, C_RED, C_WHITE, C_DARK_GREY,
    DEG2RAD,
)
from missions.mission import Mission, STATUS_ACTIVE, STATUS_COMPLETE, STATUS_FAILED
from world.regions import get_region_at

ARRIVAL_DIST = 55    # px — how close player must be to complete
MAX_ACTIVE   = 2     # simultaneous active missions


class MissionGenerator:
    """
    Generates contextual missions based on player position, world state,
    and faction influence. Handles objective checking each frame.
    """

    def __init__(self):
        self.active_missions : list[Mission] = []
        self.completed       : list[dict]    = []
        self._gen_timer      = 8.0           # start generating after 8 s

        # Notification state
        self._notification   = ""
        self._notif_timer    = 0.0
        self._notif_colour   = C_GOLD

    # ── generation ──────────────────────────────────────────────────────────

    def try_generate(self, player_x, player_y, regions, world_map, economy, factions):
        if len(self.active_missions) >= MAX_ACTIVE:
            return None

        current_region = get_region_at(regions, player_x, player_y)
        if not current_region:
            return None

        # Pick a random mission type weighted by zone
        weights = self._type_weights(current_region.zone_type)
        mtype   = random.choices(MISSION_TYPES, weights=weights)[0]

        # Choose target region (different from current for most types)
        target_region = random.choice(
            [r for r in regions if r != current_region] or regions)

        target_pos = target_region.random_road_point(world_map)
        start_pos  = (player_x, player_y)

        # Faction giving the mission
        dominant = current_region.dominant_faction()

        reward_mult = economy.mission_reward_modifier(current_region)

        m = Mission(
            mtype        = mtype,
            target_pos   = target_pos,
            start_pos    = start_pos,
            region_name  = target_region.name,
            giver_faction= dominant,
            reward_mult  = reward_mult,
        )

        if mtype == 'RETRIEVE':
            # Phase 2 drop-off is in yet another region
            drop_region = random.choice(
                [r for r in regions if r != target_region] or regions)
            m.phase_target = drop_region.random_road_point(world_map)

        self.active_missions.append(m)
        self._notify(f"NEW MISSION: {mtype}", C_GOLD)
        return m

    # ── update ───────────────────────────────────────────────────────────────

    def update(self, dt: float, player, regions, world_map,
               economy, factions, crime_system):
        # Auto-generation timer
        self._gen_timer -= dt
        if self._gen_timer <= 0:
            self._gen_timer = MISSION_GEN_INTERVAL
            self.try_generate(
                player.x, player.y, regions, world_map, economy, factions)

        # Update notification
        if self._notif_timer > 0:
            self._notif_timer -= dt

        # Update each mission
        finished = []
        for m in self.active_missions:
            if not m.is_active():
                finished.append(m)
                continue

            result = m.update(dt)
            if result == STATUS_FAILED:
                finished.append(m)
                self._on_failed(m, crime_system)
                continue

            # Check arrival
            dist = m.distance_to_target(player.x, player.y)
            if dist < ARRIVAL_DIST:
                if m.mtype == 'EVADE':
                    # Must be low heat to succeed
                    if crime_system.heat < 30:
                        m.complete()
                        finished.append(m)
                        self._on_complete(m, player, regions, factions, crime_system)
                    # else just keep trying
                elif m.mtype == 'RETRIEVE' and m.phase == 0:
                    # Pick up — advance to phase 1
                    m.phase = 1
                    crime_system.add_heat(HEAT_RETRIEVE := 6.0, "ASSET RETRIEVED")
                    self._notify("ASSET COLLECTED — DELIVER TO DROP-OFF", C_CYAN)
                else:
                    m.complete()
                    finished.append(m)
                    self._on_complete(m, player, regions, factions, crime_system)

        for m in finished:
            if m in self.active_missions:
                self.active_missions.remove(m)

    # ── callbacks ────────────────────────────────────────────────────────────

    def _on_complete(self, m: Mission, player, regions, factions, crime_system):
        summary = m.completion_summary()
        self.completed.append(summary)
        player.award(m.reward)
        # Faction rep
        region = get_region_at(regions, *m.target_pos)
        if region:
            factions.player_helped_faction(m.giver_faction, region)
        # Completing reduces heat slightly
        crime_system.reduce_heat(5.0)
        self._notify(
            f"MISSION COMPLETE  +£{m.reward:,}", C_GOLD)

    def _on_failed(self, m: Mission, crime_system):
        self.completed.append(m.completion_summary())
        crime_system.add_heat(8.0, "MISSION FAILED")
        self._notify(f"MISSION FAILED — {m.mtype}", C_RED)

    def _notify(self, text: str, colour):
        self._notification  = text
        self._notif_timer   = 4.0
        self._notif_colour  = colour

    # ── helpers ──────────────────────────────────────────────────────────────

    @staticmethod
    def _type_weights(zone_type: str):
        # [DELIVERY, EVADE, REACH_TARGET, RETRIEVE, ESCORT]
        weights_map = {
            'city':       [4, 2, 3, 3, 2],
            'industrial': [3, 3, 2, 4, 1],
            'transport':  [4, 2, 3, 3, 2],
            'outskirts':  [2, 3, 3, 2, 3],
        }
        return weights_map.get(zone_type, [3, 2, 3, 3, 2])

    def get_active_primary(self) -> Mission | None:
        for m in self.active_missions:
            if m.is_active():
                return m
        return None

    def notification_active(self):
        return self._notif_timer > 0

    # ── rendering ────────────────────────────────────────────────────────────

    def render_markers(self, surface: pygame.Surface,
                       cam_x: float, cam_y: float,
                       font_sm, elapsed: float):
        """Draw objective markers in world space."""
        for m in self.active_missions:
            if not m.is_active():
                continue
            tx, ty = m.active_target
            sx = int(tx - cam_x)
            sy = int(ty - cam_y)

            col    = m.colour
            pulse  = 0.6 + 0.4 * math.sin(elapsed * 3.0)
            r      = int(18 + 6 * pulse)

            # Outer ring
            pygame.draw.circle(surface, col, (sx, sy), r, 2)
            # Crosshair
            pygame.draw.line(surface, col, (sx - r, sy), (sx + r, sy), 1)
            pygame.draw.line(surface, col, (sx, sy - r), (sx, sy + r), 1)
            # Inner dot
            pygame.draw.circle(surface, col, (sx, sy), 5)

            # Distance label
            dist = m.distance_to_target(sx + cam_x, sy + cam_y)
            lbl  = font_sm.render(
                f"{m.mtype}  {int(dist)}m", True, col)
            surface.blit(lbl, (sx - lbl.get_width() // 2, sy - r - 18))

    def render_notification(self, surface: pygame.Surface, font_md, font_sm):
        if self._notif_timer <= 0:
            return
        alpha = min(1.0, self._notif_timer / 0.5) * min(1.0, self._notif_timer)
        col   = self._notif_colour
        cx    = surface.get_width() // 2
        lbl   = font_md.render(self._notification, True, col)
        surface.blit(lbl, (cx - lbl.get_width() // 2, 80))
