"""
AURORA BRITANNIA — Faction System
"""
import random
from utils.config import FACTION_NAMES, FACTION_COLS, FACTION_SPREAD_RATE


class Faction:
    def __init__(self, idx: int):
        self.idx    = idx
        self.name   = FACTION_NAMES[idx]
        self.colour = FACTION_COLS[idx]
        self.rep    = 50    # player reputation 0–100
        self.power  = 100   # global power level

    def adjust_rep(self, delta: float):
        self.rep = max(0, min(100, self.rep + delta))

    def is_hostile(self):
        return self.rep < 25

    def is_allied(self):
        return self.rep > 70


class FactionSystem:
    """Manages inter-faction dynamics and territory spread."""

    def __init__(self, regions: list):
        self.factions = [Faction(i) for i in range(4)]
        self.regions  = regions
        self._tick_t  = 0.0

    def update(self, dt: float, player_region):
        self._tick_t += dt

        # Slow territory spread every 2 seconds
        if self._tick_t >= 2.0:
            self._tick_t = 0.0
            for region in self.regions:
                region.spread_faction(dt * 2.0)

            # Random power fluctuations
            for f in self.factions:
                f.power = max(10, min(200,
                    f.power + random.uniform(-1, 1)))

    def player_helped_faction(self, faction_idx: int, region):
        """Player completed a mission that benefits a faction."""
        f = self.factions[faction_idx]
        f.adjust_rep(8.0)
        region.shift_faction(faction_idx, 0.04)
        # Rivals lose rep
        for i, other in enumerate(self.factions):
            if i != faction_idx:
                other.adjust_rep(-2.0)

    def player_harmed_faction(self, faction_idx: int, region):
        f = self.factions[faction_idx]
        f.adjust_rep(-10.0)
        region.shift_faction(faction_idx, -0.05)

    def get_dominant_in_region(self, region) -> int:
        return region.dominant_faction()

    def get_faction(self, idx: int) -> Faction:
        return self.factions[idx]

    def summary_lines(self):
        lines = []
        for f in self.factions:
            bar_len = int(f.rep / 5)
            bar = '█' * bar_len + '░' * (20 - bar_len)
            lines.append((f.name, bar, f.rep, f.colour))
        return lines
