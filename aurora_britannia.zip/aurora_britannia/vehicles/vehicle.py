"""
AURORA BRITANNIA — Vehicle System
"""
import math
import pygame
from utils.config import (
    VEHICLE_TYPES, TILE_SIZE, DEG2RAD, RAD2DEG,
    C_WHITE, C_DARK_GREY, C_GREY, WORLD_W, WORLD_H,
)

_NEXT_VID = 0


def _next_id():
    global _NEXT_VID
    _NEXT_VID += 1
    return _NEXT_VID


class Vehicle:
    """Arcade-physics drivable vehicle."""

    def __init__(self, wx: float, wy: float, vtype: str = "CAR", angle: float = 0.0):
        self.vid      = _next_id()
        self.vtype    = vtype
        cfg           = VEHICLE_TYPES[vtype]

        self.x        = float(wx)
        self.y        = float(wy)
        self.angle    = float(angle)   # degrees, 0 = right, 90 = down
        self.speed    = 0.0            # px/s along heading

        self.max_speed  = cfg['max_speed']
        self.accel      = cfg['accel']
        self.brake_str  = cfg['brake']
        self.friction   = cfg['friction']
        self.turn_speed = cfg['turn_speed']
        self.durability = cfg['durability']
        self.max_dur    = cfg['durability']
        self.width      = cfg['width']
        self.height     = cfg['height']
        self.colour     = cfg['colour']

        self.driver     = None   # Player or None
        self.active     = True

        # Pre-build surface
        self._surf = self._build_surf()

    def _build_surf(self):
        w, h  = self.width * 2, self.height * 2
        surf  = pygame.Surface((w + 4, h + 4), pygame.SRCALPHA)
        cx, cy = (w + 4) // 2, (h + 4) // 2

        # Body
        body_rect = pygame.Rect(cx - self.width, cy - self.height,
                                self.width * 2, self.height * 2)
        pygame.draw.rect(surf, self.colour, body_rect, border_radius=4)

        # Windscreen (lighter strip)
        ws_w = int(self.width * 0.6)
        ws_h = int(self.height * 0.8)
        ws_rect = pygame.Rect(cx + self.width // 4 - ws_w // 2,
                              cy - ws_h // 2, ws_w, ws_h)
        wscol = tuple(min(255, c + 60) for c in self.colour)
        pygame.draw.rect(surf, wscol, ws_rect, border_radius=2)

        # Headlights
        for sy in (-self.height // 2, self.height // 2 - 3):
            pygame.draw.rect(surf, (255, 255, 180),
                             (cx + self.width - 3, cy + sy, 4, 3))
        # Taillights
        for sy in (-self.height // 2, self.height // 2 - 3):
            pygame.draw.rect(surf, (200, 20, 20),
                             (cx - self.width - 1, cy + sy, 4, 3))

        return surf

    # ── update ──────────────────────────────────────────────────────────────

    def driven_update(self, keys, dt: float, world_map):
        """Called each frame when a player is driving."""
        fwd   = keys[pygame.K_w] or keys[pygame.K_UP]
        back  = keys[pygame.K_s] or keys[pygame.K_DOWN]
        left  = keys[pygame.K_a] or keys[pygame.K_LEFT]
        right = keys[pygame.K_d] or keys[pygame.K_RIGHT]

        # Acceleration / deceleration
        if fwd:
            self.speed = min(self.speed + self.accel * dt, self.max_speed)
        elif back:
            self.speed = max(self.speed - self.brake_str * dt, -self.max_speed * 0.3)
        else:
            # Friction
            if self.speed > 0:
                self.speed = max(0.0, self.speed - self.friction * dt)
            else:
                self.speed = min(0.0, self.speed + self.friction * dt)

        # Steering (proportional to speed)
        if abs(self.speed) > 8:
            steer_factor = min(1.0, abs(self.speed) / (self.max_speed * 0.4))
            turn = self.turn_speed * steer_factor * dt
            if self.speed < 0:
                turn = -turn
            if left:
                self.angle -= turn
            if right:
                self.angle += turn

        self._move(dt, world_map)

    def free_update(self, dt: float, world_map):
        """Coasts to a stop when no driver."""
        if self.speed > 0:
            self.speed = max(0.0, self.speed - self.friction * 2 * dt)
        elif self.speed < 0:
            self.speed = min(0.0, self.speed + self.friction * 2 * dt)
        if abs(self.speed) > 0.5:
            self._move(dt, world_map)

    def _move(self, dt: float, world_map):
        rad = self.angle * DEG2RAD
        nx  = self.x + math.cos(rad) * self.speed * dt
        ny  = self.y + math.sin(rad) * self.speed * dt

        # Clamp to world
        nx = max(self.width + 2, min(WORLD_W - self.width - 2, nx))
        ny = max(self.height + 2, min(WORLD_H - self.height - 2, ny))

        # Collision — check corners
        hw, hh = self.width + 2, self.height + 2
        rad90  = rad + math.pi / 2
        corners = [
            (nx + math.cos(rad) * hw + math.cos(rad90) * hh,
             ny + math.sin(rad) * hw + math.sin(rad90) * hh),
            (nx + math.cos(rad) * hw - math.cos(rad90) * hh,
             ny + math.sin(rad) * hw - math.sin(rad90) * hh),
            (nx - math.cos(rad) * hw + math.cos(rad90) * hh,
             ny - math.sin(rad) * hw + math.sin(rad90) * hh),
            (nx - math.cos(rad) * hw - math.cos(rad90) * hh,
             ny - math.sin(rad) * hw - math.sin(rad90) * hh),
        ]
        blocked = any(world_map.is_solid(cx, cy) for cx, cy in corners)
        if blocked:
            # absorb impact
            self.durability -= abs(self.speed) * 0.002
            self.speed *= -0.3
        else:
            self.x, self.y = nx, ny

    # ── AI steering (for pursuit vehicles) ─────────────────────────────────

    def ai_steer_toward(self, tx: float, ty: float, dt: float, world_map):
        """Basic AI: steer and accelerate toward target."""
        dx, dy   = tx - self.x, ty - self.y
        dist     = math.hypot(dx, dy)
        if dist < 20:
            return

        target_angle = math.atan2(dy, dx) * RAD2DEG
        da = (target_angle - self.angle + 180) % 360 - 180
        turn = self.turn_speed * dt * 1.2
        self.angle += max(-turn, min(turn, da))
        self.speed = min(self.speed + self.accel * dt, self.max_speed * 0.85)
        self._move(dt, world_map)

    # ── geometry helpers ────────────────────────────────────────────────────

    def world_rect(self):
        return pygame.Rect(self.x - self.width, self.y - self.height,
                           self.width * 2, self.height * 2)

    def distance_to(self, wx, wy):
        return math.hypot(wx - self.x, wy - self.y)

    # ── rendering ───────────────────────────────────────────────────────────

    def render(self, surface: pygame.Surface, cam_x: float, cam_y: float):
        sx = int(self.x - cam_x)
        sy = int(self.y - cam_y)

        # Cull off-screen
        if sx < -80 or sx > surface.get_width() + 80:
            return
        if sy < -80 or sy > surface.get_height() + 80:
            return

        rotated = pygame.transform.rotate(self._surf, -self.angle)
        rect    = rotated.get_rect(center=(sx, sy))
        surface.blit(rotated, rect)

        # Shadow under vehicle
        if self.driver:
            shadow = pygame.Surface((self.width * 2 + 4, 8), pygame.SRCALPHA)
            shadow.fill((0, 0, 0, 60))
            surface.blit(shadow, (sx - self.width - 2, sy + self.height))

        # Health bar if damaged
        if self.durability < self.max_dur:
            ratio = self.durability / self.max_dur
            bar_w = self.width * 2
            pygame.draw.rect(surface, (50, 50, 60),
                             (sx - self.width, sy - self.height - 6, bar_w, 4))
            col = (0, 200, 80) if ratio > 0.5 else (255, 140, 0) if ratio > 0.25 else (220, 30, 30)
            pygame.draw.rect(surface, col,
                             (sx - self.width, sy - self.height - 6, int(bar_w * ratio), 4))

    def render_enter_hint(self, surface: pygame.Surface, cam_x: float, cam_y: float,
                          font: pygame.font.Font):
        sx = int(self.x - cam_x)
        sy = int(self.y - cam_y)
        txt = font.render("[E] ENTER", True, (201, 162, 39))
        surface.blit(txt, (sx - txt.get_width() // 2, sy - self.height - 20))
