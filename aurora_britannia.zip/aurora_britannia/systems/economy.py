"""
AURORA BRITANNIA — Economy System
"""
import random
from utils.config import ECONOMY_TICK, BASE_WEALTH


class EconomySystem:
    """
    Simple per-region economy simulation.
    Wealth drifts, trade happens between adjacent regions,
    crime suppresses economic activity.
    """

    def __init__(self, regions: list):
        self.regions  = regions
        self._tick_t  = 0.0
        self.prices   = {}   # commodity -> price
        self._init_prices()

    def _init_prices(self):
        commodities = ["FUEL", "CARGO", "TECH", "MATERIALS", "FOOD"]
        for c in commodities:
            self.prices[c] = random.randint(80, 200)

    def update(self, dt: float, player_region):
        self._tick_t += dt
        if self._tick_t < ECONOMY_TICK:
            return
        self._tick_t = 0.0

        for region in self.regions:
            # Crime suppresses wealth
            crime_penalty = region.crime_level * 30
            recovery = (BASE_WEALTH - region.wealth) * 0.05
            noise    = random.uniform(-10, 15)
            region.wealth += recovery + noise - crime_penalty
            region.wealth  = max(200, min(3000, region.wealth))

        # Price fluctuations
        for c in self.prices:
            self.prices[c] += random.uniform(-5, 6)
            self.prices[c]  = max(30, min(500, self.prices[c]))

    def get_price(self, commodity: str) -> float:
        return self.prices.get(commodity, 100)

    def mission_reward_modifier(self, region) -> float:
        """Higher wealth = slightly better mission rewards."""
        return 0.8 + (region.wealth / BASE_WEALTH) * 0.4

    def richest_region(self):
        return max(self.regions, key=lambda r: r.wealth)

    def poorest_region(self):
        return min(self.regions, key=lambda r: r.wealth)
