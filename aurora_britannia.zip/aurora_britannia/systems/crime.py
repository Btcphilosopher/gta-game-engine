"""
AURORA BRITANNIA — Crime & Heat System
"""
import random
from utils.config import (
    MAX_HEAT, HEAT_DECAY_IDLE, HEAT_DECAY_MOVING,
    HEAT_SPEEDING, HEAT_ZONE_TRIG, HEAT_MISSION,
    PURSUIT_HEAT_THRESHOLD, MAX_PURSUERS,
)


class CrimeSystem:
    """
    Tracks the player's heat level and manages the wanted response.
    Heat decays naturally; actions push it up.  Above threshold, pursuers spawn.
    """

    def __init__(self):
        self.heat             = 0.0    # 0–100
        self._pursuit_timer   = 0.0    # delay between spawns
        self._spawn_interval  = 12.0   # seconds between spawner checks
        self._zone_visited    = set()  # restricted zones already penalised

        # For accumulation events
        self._events: list[str] = []   # recent event log

    # ── heat manipulation ────────────────────────────────────────────────────

    def add_heat(self, amount: float, reason: str = ""):
        self.heat = min(MAX_HEAT, self.heat + amount)
        if reason:
            self._events.append(reason)
            if len(self._events) > 5:
                self._events.pop(0)

    def reduce_heat(self, amount: float):
        self.heat = max(0.0, self.heat - amount)

    def clear_heat(self):
        self.heat = 0.0
        self._zone_visited.clear()
        self._events.clear()

    # ── update ───────────────────────────────────────────────────────────────

    def update(self, dt: float, player, regions, npc_system):
        # Sync heat to player
        player.heat = self.heat

        # Detect speeding
        if player.speeding:
            self.add_heat(HEAT_SPEEDING * dt, "SPEEDING")

        # Restricted zone detection
        from world.regions import get_region_at
        region = get_region_at(regions, player.x, player.y)
        if region and region.restricted:
            rid = region.name
            if rid not in self._zone_visited:
                self._zone_visited.add(rid)
                self.add_heat(HEAT_ZONE_TRIG, "RESTRICTED ZONE")

        # Heat decay
        moving  = (player.in_vehicle() and abs(player.vehicle.speed) > 20) \
                  or (not player.in_vehicle())
        decay   = HEAT_DECAY_MOVING if moving else HEAT_DECAY_IDLE
        self.heat = max(0.0, self.heat - decay * dt)

        # Pursuer management
        self._pursuit_timer -= dt
        if self.heat >= PURSUIT_HEAT_THRESHOLD:
            if self._pursuit_timer <= 0:
                current = len(npc_system.pursuers)
                wanted_count = self._wanted_count()
                if current < wanted_count:
                    npc_system.spawn_pursuer(player.x, player.y, None)
                    # world_map injected via spawn_pursuer — handled by GameState
                    self._pursuit_timer = self._spawn_interval
                    self.add_heat(0, "PURSUIT DISPATCHED")
        else:
            # Below threshold — dismiss pursuers
            if self.heat < 10:
                npc_system.clear_pursuers()

        npc_system.remove_excess_pursuers(MAX_PURSUERS)

        # Check if caught
        if npc_system.pursuer_near_player(player.x, player.y, 30):
            self._on_caught(player)

    def update_spawn(self, dt: float, player, npc_system, world_map):
        """Called after world_map is available."""
        if self.heat >= PURSUIT_HEAT_THRESHOLD:
            if self._pursuit_timer <= 0:
                current = len(npc_system.pursuers)
                if current < self._wanted_count():
                    npc_system.spawn_pursuer(player.x, player.y, world_map)
                    self._pursuit_timer = self._spawn_interval

    # ── helpers ──────────────────────────────────────────────────────────────

    def _wanted_count(self) -> int:
        if self.heat < 30:   return 0
        if self.heat < 50:   return 1
        if self.heat < 70:   return 2
        if self.heat < 85:   return 4
        return MAX_PURSUERS

    def _on_caught(self, player):
        """Player was caught — financial penalty, heat cleared."""
        fine = int(self.heat * 12)
        player.penalise(fine)
        self.clear_heat()
        self._events.append(f"CAUGHT — £{fine} FINE")

    def heat_level_name(self) -> str:
        h = self.heat
        if h < 15:  return "CLEAR"
        if h < 30:  return "NOTICED"
        if h < 50:  return "WANTED"
        if h < 70:  return "PURSUED"
        if h < 85:  return "HUNTED"
        return "MOST WANTED"

    def heat_colour(self):
        h = self.heat
        if h < 15:  return (0, 210, 90)
        if h < 30:  return (180, 200, 0)
        if h < 50:  return (255, 160, 0)
        if h < 70:  return (255, 80, 0)
        return (255, 30, 30)

    def recent_events(self):
        return list(self._events)
