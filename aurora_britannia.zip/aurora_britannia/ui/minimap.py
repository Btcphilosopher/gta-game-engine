"""
AURORA BRITANNIA — Minimap
"""
import math
import pygame
from utils.config import (
    MINIMAP_SIZE, MINIMAP_MARGIN, MINIMAP_SCALE,
    WORLD_W, WORLD_H, SCREEN_W, SCREEN_H,
    TILE_SIZE, MAP_W, MAP_H,
    TILE_ROAD, TILE_BUILDING, TILE_PAVEMENT, TILE_PARK,
    TILE_WATER, TILE_INDUSTRIAL, TILE_RAIL,
    C_BG, C_ROAD, C_PAVEMENT, C_PARK, C_WATER, C_INDUSTRIAL, C_RAIL,
    C_BUILDING_CITY, C_CYAN, C_GOLD, C_RED, C_WHITE, C_DARK_GREY,
    FACTION_COLS,
)

# Reduced-palette for minimap tiles (must be opaque)
_MM_TILE_COL = {
    TILE_ROAD:       (35,  38,  58),
    TILE_BUILDING:   (22,  30,  55),
    TILE_PAVEMENT:   (28,  32,  50),
    TILE_PARK:       (18,  52,  22),
    TILE_WATER:      (12,  38,  72),
    TILE_INDUSTRIAL: (48,  34,  22),
    TILE_RAIL:       (55,  48,  30),
}
_MM_DEFAULT  = (20, 22, 35)


class Minimap:
    """
    Renders a small top-right overview of the world map.
    The static tile layer is pre-baked into a Surface; dynamic
    elements (player, vehicles, NPCs, missions) are drawn each frame.
    """

    def __init__(self, world_map):
        self.size    = MINIMAP_SIZE
        self.scale   = self.size / max(WORLD_W, WORLD_H)
        self._base   = self._bake_base(world_map)
        self._border_col  = (50, 55, 80)
        self._bg_col      = (10, 12, 22, 210)

    # ── bake ────────────────────────────────────────────────────────────────

    def _bake_base(self, world_map) -> pygame.Surface:
        surf = pygame.Surface((self.size, self.size))
        surf.fill((10, 12, 22))

        # Draw each tile as one pixel (approx) scaled
        tile_px_w = max(1, int(TILE_SIZE * self.scale))
        tile_px_h = max(1, int(TILE_SIZE * self.scale))

        for ty in range(MAP_H):
            for tx in range(MAP_W):
                t   = world_map.get_tile_t(tx, ty)
                col = _MM_TILE_COL.get(t, _MM_DEFAULT)
                mx  = int(tx * TILE_SIZE * self.scale)
                my  = int(ty * TILE_SIZE * self.scale)
                if tile_px_w >= 1 and tile_px_h >= 1:
                    pygame.draw.rect(surf, col, (mx, my, tile_px_w, tile_px_h))
        return surf

    # ── render ───────────────────────────────────────────────────────────────

    def render(self, surface: pygame.Surface, player, vehicles,
               npc_system, missions, regions):
        sw = surface.get_width()
        ox = sw - self.size - MINIMAP_MARGIN
        oy = MINIMAP_MARGIN

        # Background panel with alpha
        bg = pygame.Surface((self.size + 4, self.size + 4), pygame.SRCALPHA)
        bg.fill((10, 12, 22, 210))
        surface.blit(bg, (ox - 2, oy - 2))

        # Base map
        surface.blit(self._base, (ox, oy))

        # Region faction tint overlay (very subtle)
        for region in regions:
            col  = region.dominant_colour()
            rx   = int(region.wx0 * self.scale) + ox
            ry   = int(region.wy0 * self.scale) + oy
            rw   = int((region.wx1 - region.wx0) * self.scale)
            rh   = int((region.wy1 - region.wy0) * self.scale)
            tint = pygame.Surface((rw, rh), pygame.SRCALPHA)
            tint.fill((*col, 25))
            surface.blit(tint, (rx, ry))

        # Mission targets
        for m in missions:
            if m.is_active():
                tx, ty = m.active_target
                mx = int(tx * self.scale) + ox
                my = int(ty * self.scale) + oy
                pygame.draw.circle(surface, m.colour, (mx, my), 4)
                pygame.draw.circle(surface, (255, 255, 255), (mx, my), 4, 1)

        # Vehicles
        for v in vehicles:
            if v.driver is None:
                vx = int(v.x * self.scale) + ox
                vy = int(v.y * self.scale) + oy
                pygame.draw.rect(surface, (100, 150, 220),
                                 (vx - 1, vy - 1, 3, 3))

        # Pursuers
        for p in npc_system.pursuers:
            px2 = int(p.x * self.scale) + ox
            py2 = int(p.y * self.scale) + oy
            pygame.draw.circle(surface, (80, 100, 255), (px2, py2), 3)

        # Player blip
        ppx = int(player.x * self.scale) + ox
        ppy = int(player.y * self.scale) + oy
        pygame.draw.circle(surface, (0, 212, 255), (ppx, ppy), 4)
        pygame.draw.circle(surface, (255, 255, 255), (ppx, ppy), 4, 1)

        # Viewport indicator rectangle
        vx0 = int((player.x - SCREEN_W / 2) * self.scale) + ox
        vy0 = int((player.y - SCREEN_H / 2) * self.scale) + oy
        vw  = int(SCREEN_W * self.scale)
        vh  = int(SCREEN_H * self.scale)
        view_surf = pygame.Surface((vw, vh), pygame.SRCALPHA)
        view_surf.fill((255, 255, 255, 12))
        surface.blit(view_surf, (vx0, vy0))
        pygame.draw.rect(surface, (80, 90, 130),
                         (vx0, vy0, vw, vh), 1)

        # Border
        pygame.draw.rect(surface, self._border_col,
                         (ox - 1, oy - 1, self.size + 2, self.size + 2), 1)

        # Compass label
        # (rendered by HUD)
