"""
AURORA BRITANNIA — HUD (Heads-Up Display)
"""
import math
import pygame
from utils.config import (
    SCREEN_W, SCREEN_H, MAX_HEAT,
    C_GOLD, C_CYAN, C_RED, C_GREEN, C_ORANGE, C_WHITE, C_GREY,
    C_DARK_GREY, C_BG, FACTION_COLS, FACTION_NAMES,
    FONT_SM, FONT_MD, FONT_LG, FONT_XL,
)


class HUD:
    """
    Renders all overlay elements:
      • Speed / vehicle state bar (bottom-left)
      • Heat gauge (top-left)
      • Active mission panel (left side)
      • Cash / region info (top bar)
      • Event log
      • Faction influence sidebar (toggleable)
      • Mini compass (top-right corner)
    """

    def __init__(self):
        self._fonts       = {}
        self._elapsed     = 0.0
        self._show_factions = False
        self._panel_alpha   = 200

    # ── font helpers ─────────────────────────────────────────────────────────

    def load_fonts(self):
        candidates = ['consolas', 'couriernew', 'dejavusansmono',
                      'liberationmono', 'monospace']
        for name in candidates:
            try:
                self._fonts['sm']  = pygame.font.SysFont(name, FONT_SM)
                self._fonts['md']  = pygame.font.SysFont(name, FONT_MD)
                self._fonts['lg']  = pygame.font.SysFont(name, FONT_LG)
                self._fonts['xl']  = pygame.font.SysFont(name, FONT_XL, bold=True)
                break
            except Exception:
                continue
        if not self._fonts:
            for key, size in (('sm', FONT_SM), ('md', FONT_MD),
                              ('lg', FONT_LG), ('xl', FONT_XL)):
                self._fonts[key] = pygame.font.Font(None, size + 4)

    def f(self, key='md') -> pygame.font.Font:
        return self._fonts.get(key, self._fonts.get('md'))

    # ── main render ──────────────────────────────────────────────────────────

    def render(self, surface: pygame.Surface, dt: float,
               player, region, crime_system, missions_gen,
               factions, economy, fps: int):
        self._elapsed += dt
        t = self._elapsed

        self._draw_top_bar(surface, player, region, fps)
        self._draw_heat_gauge(surface, crime_system, t)
        self._draw_vehicle_gauge(surface, player, t)
        self._draw_mission_panel(surface, missions_gen, t)
        self._draw_event_log(surface, crime_system)
        self._draw_region_tag(surface, region, t)

        if self._show_factions:
            self._draw_faction_sidebar(surface, factions, region)

        # Compass
        self._draw_compass(surface, player)

        # Mission notifications
        missions_gen.render_notification(surface, self.f('lg'), self.f('md'))

    # ── sub-panels ───────────────────────────────────────────────────────────

    def _draw_top_bar(self, surface, player, region, fps):
        """Thin top strip: game title / cash / fps."""
        bar_h = 28
        bar   = pygame.Surface((SCREEN_W, bar_h), pygame.SRCALPHA)
        bar.fill((8, 10, 20, 200))
        surface.blit(bar, (0, 0))

        # Title
        title = self.f('sm').render("AURORA BRITANNIA", True, C_GOLD)
        surface.blit(title, (10, (bar_h - title.get_height()) // 2))

        # Cash
        cash_txt = self.f('md').render(f"£{player.cash:,}", True, C_GREEN)
        surface.blit(cash_txt, (SCREEN_W // 2 - cash_txt.get_width() // 2,
                                (bar_h - cash_txt.get_height()) // 2))

        # FPS
        fps_col = C_GREEN if fps >= 55 else C_ORANGE if fps >= 30 else C_RED
        fps_txt = self.f('sm').render(f"{fps} FPS", True, fps_col)
        surface.blit(fps_txt, (SCREEN_W - fps_txt.get_width() - 220,
                               (bar_h - fps_txt.get_height()) // 2))

        # Separator line
        pygame.draw.line(surface, (40, 45, 70), (0, bar_h), (SCREEN_W, bar_h), 1)

    def _draw_heat_gauge(self, surface, crime_system, t):
        """Left side: heat bar + warning text."""
        x, y = 12, 40
        w, h  = 160, 10
        heat  = crime_system.heat
        ratio = heat / MAX_HEAT
        col   = crime_system.heat_colour()
        name  = crime_system.heat_level_name()

        # Background
        bg = pygame.Surface((w + 60, 56), pygame.SRCALPHA)
        bg.fill((8, 10, 20, 180))
        surface.blit(bg, (x - 4, y - 4))

        # Label
        label = self.f('sm').render("HEAT", True, C_GREY)
        surface.blit(label, (x, y))

        # Bar track
        pygame.draw.rect(surface, (30, 30, 45), (x, y + 14, w, h))
        # Bar fill
        fill_w = int(w * ratio)
        if fill_w > 0:
            # Gradient effect — draw in segments
            for i in range(fill_w):
                shade = tuple(min(255, int(c * (0.5 + 0.5 * i / w))) for c in col)
                pygame.draw.line(surface, shade,
                                 (x + i, y + 14), (x + i, y + 14 + h - 1))
        pygame.draw.rect(surface, (50, 55, 80), (x, y + 14, w, h), 1)

        # Tick marks at 25, 50, 75
        for pct in (25, 50, 75):
            tx = x + int(w * pct / 100)
            pygame.draw.line(surface, (60, 65, 90), (tx, y + 14), (tx, y + 24))

        # Status name
        blink = heat > 60 and (int(t * 4) % 2 == 0)
        name_col = col if blink else C_GREY
        name_txt = self.f('sm').render(name, True, name_col)
        surface.blit(name_txt, (x, y + 28))

    def _draw_vehicle_gauge(self, surface, player, t):
        """Bottom-left: speed + vehicle type when driving."""
        if not player.in_vehicle():
            # On-foot indicator
            x, y = 12, SCREEN_H - 80
            bg = pygame.Surface((160, 50), pygame.SRCALPHA)
            bg.fill((8, 10, 20, 180))
            surface.blit(bg, (x - 4, y - 4))
            foot = self.f('sm').render("ON FOOT", True, C_CYAN)
            surface.blit(foot, (x, y))
            return

        v   = player.vehicle
        spd = abs(v.speed)
        x, y = 12, SCREEN_H - 100

        bg = pygame.Surface((200, 80), pygame.SRCALPHA)
        bg.fill((8, 10, 20, 200))
        surface.blit(bg, (x - 4, y - 4))

        # Vehicle type
        vt  = self.f('md').render(v.vtype, True, v.colour)
        surface.blit(vt, (x, y))

        # Speed bar
        ratio = spd / v.max_speed
        bar_w = 160
        pygame.draw.rect(surface, (25, 28, 45), (x, y + 22, bar_w, 8))
        spd_col = C_RED if ratio > 0.85 else C_ORANGE if ratio > 0.6 else C_CYAN
        pygame.draw.rect(surface, spd_col, (x, y + 22, int(bar_w * ratio), 8))
        pygame.draw.rect(surface, (50, 55, 80), (x, y + 22, bar_w, 8), 1)

        # Speed number
        spd_txt = self.f('lg').render(f"{int(spd * 0.036)} km/h", True, C_WHITE)
        surface.blit(spd_txt, (x, y + 36))

        # Durability
        dur_ratio = v.durability / v.max_dur
        dur_col   = C_GREEN if dur_ratio > 0.5 else C_ORANGE if dur_ratio > 0.25 else C_RED
        dur_txt   = self.f('sm').render(
            f"HULL  {'█' * int(dur_ratio * 10)}{'░' * (10 - int(dur_ratio * 10))}",
            True, dur_col)
        surface.blit(dur_txt, (x, y + 60))

    def _draw_mission_panel(self, surface, missions_gen, t):
        """Left panel showing active mission(s)."""
        missions = [m for m in missions_gen.active_missions if m.is_active()]
        if not missions:
            return

        x, y   = 12, SCREEN_H - 240
        panel_w = 220
        panel_h = len(missions) * 80 + 10

        bg = pygame.Surface((panel_w, panel_h), pygame.SRCALPHA)
        bg.fill((8, 10, 20, 195))
        surface.blit(bg, (x - 4, y - 4))

        pygame.draw.line(surface, C_GOLD, (x - 4, y - 4), (x - 4, y + panel_h - 4), 2)

        for idx, m in enumerate(missions):
            my = y + idx * 80
            lines = m.hud_lines()

            # Time urgency colour
            time_col = C_GREEN if m.time_left > 30 else \
                       C_ORANGE if m.time_left > 10 else C_RED

            for li, line in enumerate(lines):
                col = m.colour if li == 0 else \
                      time_col if li == 2 else C_WHITE
                txt = self.f('sm').render(line, True, col)
                surface.blit(txt, (x, my + li * 16))

            # Progress to target
            dist = m.distance_to_target(0, 0)   # just for gauge
            pygame.draw.line(surface, (40, 45, 65),
                             (x, my + 68), (x + panel_w - 16, my + 68))

    def _draw_event_log(self, surface, crime_system):
        """Small scrolling event log bottom-right."""
        events = crime_system.recent_events()
        if not events:
            return
        x = SCREEN_W - 240
        y = SCREEN_H - 30 - len(events) * 18

        for i, ev in enumerate(reversed(events[-4:])):
            alpha = max(60, 255 - i * 50)
            col   = tuple(min(255, int(c * alpha / 255)) for c in C_ORANGE)
            txt   = self.f('sm').render(f"// {ev}", True, col)
            surface.blit(txt, (x, y + i * 18))

    def _draw_region_tag(self, surface, region, t):
        """Subtle zone name in top-right (below minimap area)."""
        if not region:
            return
        x = SCREEN_W - 216
        y = 228

        txt  = self.f('sm').render(region.name, True, region.dominant_colour())
        zone = self.f('sm').render(
            f"ZONE: {region.zone_type.upper()}", True, C_GREY)
        crime= self.f('sm').render(
            f"CRIME: {region.crime_level * 100:.0f}%", True, C_GREY)

        surface.blit(txt,   (x, y))
        surface.blit(zone,  (x, y + 16))
        surface.blit(crime, (x, y + 32))

    def _draw_faction_sidebar(self, surface, factions, region):
        """Right side: faction influence bars (toggle with TAB)."""
        x, y  = SCREEN_W - 260, 280
        panel = pygame.Surface((245, 115), pygame.SRCALPHA)
        panel.fill((8, 10, 20, 210))
        surface.blit(panel, (x, y))

        header = self.f('sm').render("FACTION INFLUENCE", True, C_GOLD)
        surface.blit(header, (x + 4, y + 4))
        pygame.draw.line(surface, (50, 55, 80), (x, y + 20), (x + 244, y + 20))

        for i, (name, bar, rep, col) in enumerate(factions.summary_lines()):
            fy  = y + 26 + i * 22
            bar_w = 100
            ratio = rep / 100
            pygame.draw.rect(surface, (25, 28, 45), (x + 100, fy, bar_w, 10))
            pygame.draw.rect(surface, col, (x + 100, fy, int(bar_w * ratio), 10))
            pygame.draw.rect(surface, (50, 55, 80), (x + 100, fy, bar_w, 10), 1)
            nt = self.f('sm').render(name[:16], True, col)
            surface.blit(nt, (x + 4, fy))

    def _draw_compass(self, surface, player):
        """Mini compass indicator near minimap."""
        cx = SCREEN_W - 108
        cy = 218
        r  = 10
        pygame.draw.circle(surface, (18, 20, 35), (cx, cy), r + 2)
        pygame.draw.circle(surface, (40, 45, 70), (cx, cy), r + 2, 1)

        # N marker
        nx = cx
        ny = cy - r + 2
        pygame.draw.line(surface, C_RED, (cx, cy), (nx, ny), 2)
        nt = self.f('sm').render("N", True, (180, 180, 200))
        surface.blit(nt, (cx - nt.get_width() // 2, cy - r - 14))

    # ── toggle ───────────────────────────────────────────────────────────────

    def toggle_factions(self):
        self._show_factions = not self._show_factions

    def font_sm(self):
        return self.f('sm')

    def font_md(self):
        return self.f('md')
