"""
AURORA BRITANNIA — Main Game Loop
"""
import sys
import pygame
from utils.config import SCREEN_W, SCREEN_H, FPS, TITLE, C_BG
from core.state import GameState


class GameLoop:
    """
    Owns the pygame window, clock, and drives the update/render cycle.
    Delta-time capped at 50 ms to prevent spiral-of-death on lag spikes.
    """

    MAX_DT = 0.05   # 50 ms cap

    def __init__(self):
        pygame.init()
        pygame.display.set_caption(TITLE)
        self.screen  = pygame.display.set_mode(
            (SCREEN_W, SCREEN_H), pygame.DOUBLEBUF | pygame.HWSURFACE)
        self.clock   = pygame.time.Clock()
        self.running = False

        # Build game state (loads map, spawns entities)
        self._loading_screen()
        self.state = GameState()
        self.state.hud.load_fonts()

        # Quick welcome mission
        self.state.missions.try_generate(
            self.state.player.x, self.state.player.y,
            self.state.regions, self.state.world_map,
            self.state.economy, self.state.factions)

    # ── loading screen ───────────────────────────────────────────────────────

    def _loading_screen(self):
        font = pygame.font.SysFont('consolas', 20) or pygame.font.Font(None, 24)
        self.screen.fill(C_BG)
        msgs = [
            "AURORA BRITANNIA",
            "",
            "SYSTEMIC OPEN WORLD ENGINE",
            "",
            "Generating map...",
            "Loading subsystems...",
        ]
        y = SCREEN_H // 2 - len(msgs) * 14
        for i, msg in enumerate(msgs):
            col  = (201, 162, 39) if i == 0 else \
                   (0, 212, 255) if i == 2 else (100, 110, 140)
            surf = font.render(msg, True, col)
            self.screen.blit(surf, (SCREEN_W // 2 - surf.get_width() // 2,
                                    y + i * 28))
        pygame.display.flip()
        pygame.event.pump()

    # ── run ──────────────────────────────────────────────────────────────────

    def run(self):
        self.running = True
        while self.running:
            dt = min(self.clock.tick(FPS) / 1000.0, self.MAX_DT)
            self.state.fps = int(self.clock.get_fps())

            self._handle_events()
            if not self.running:
                break

            keys            = pygame.key.get_pressed()
            current_region  = self.state.update(dt, keys)
            self.state.render(self.screen, current_region)

            pygame.display.flip()

        pygame.quit()
        sys.exit()

    # ── events ───────────────────────────────────────────────────────────────

    def _handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False
                self.state.handle_event(event)
            else:
                self.state.handle_event(event)
