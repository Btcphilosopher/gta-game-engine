"""
AURORA BRITANNIA — Game State
Holds every subsystem; passed as context to all update/render calls.
"""
import random
import math
import pygame
from utils.config import (
    SCREEN_W, SCREEN_H, WORLD_W, WORLD_H,
    PLAYER_SPAWN, VEHICLE_TYPES, NPC_COUNT,
    C_BG,
)
from world.map      import WorldMap
from world.regions  import build_regions, get_region_at
from player.player  import Player
from vehicles.vehicle import Vehicle
from ai.npc         import NPCSystem
from factions.factions import FactionSystem
from systems.crime  import CrimeSystem
from systems.economy import EconomySystem
from missions.generator import MissionGenerator
from ui.hud         import HUD
from ui.minimap     import Minimap


class Camera:
    """Smooth-follow camera."""
    def __init__(self):
        self.x = float(PLAYER_SPAWN[0] - SCREEN_W // 2)
        self.y = float(PLAYER_SPAWN[1] - SCREEN_H // 2)

    def follow(self, target_x: float, target_y: float, dt: float):
        tx = target_x - SCREEN_W // 2
        ty = target_y - SCREEN_H // 2
        speed = 8.0
        self.x += (tx - self.x) * speed * dt
        self.y += (ty - self.y) * speed * dt
        # Clamp
        self.x = max(0.0, min(WORLD_W - SCREEN_W, self.x))
        self.y = max(0.0, min(WORLD_H - SCREEN_H, self.y))


class GameState:
    """Central game state — owns all subsystems."""

    def __init__(self):
        # Map & regions
        self.world_map  = WorldMap()
        self.regions    = build_regions()

        # Entities
        self.player     = Player()
        self.vehicles   : list[Vehicle] = []
        self.npc_system = NPCSystem()

        # Subsystems
        self.factions     = FactionSystem(self.regions)
        self.crime        = CrimeSystem()
        self.economy      = EconomySystem(self.regions)
        self.missions     = MissionGenerator()

        # Camera
        self.camera       = Camera()

        # UI
        self.hud          = HUD()
        self.minimap      = Minimap(self.world_map)

        # Timing
        self.elapsed      = 0.0
        self.fps          = 60

        # Spawn world entities
        self._spawn_vehicles()
        self.npc_system.spawn_pedestrians(NPC_COUNT, self.world_map, self.regions)

        # Surfaces
        self._overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)

    # ── spawning ─────────────────────────────────────────────────────────────

    def _spawn_vehicles(self):
        """Scatter parked vehicles across the map on road tiles."""
        spawn_configs = [
            # (world_x, world_y, type, angle)
            # City vehicles
            (900,  780, "CAR",    0),
            (1050, 820, "SPORTS", 90),
            (780,  900, "VAN",    180),
            (1180, 760, "CAR",    0),
            (640,  640, "CAR",    270),
            (1360, 840, "SPORTS", 45),
            # Industrial
            (2600, 800, "VAN",    0),
            (2750, 760, "VAN",    90),
            (2900, 840, "CAR",    180),
            (2480, 900, "CAR",    0),
            # Transport hub
            (2700, 2200, "CAR",   90),
            (2850, 2100, "VAN",   0),
            (3000, 2300, "CAR",   270),
            # Outskirts
            (800,  2200, "CAR",   0),
            (600,  2400, "VAN",   90),
            (1000, 2600, "CAR",   180),
        ]
        for wx, wy, vtype, angle in spawn_configs:
            # Snap to nearest road
            rx, ry = self.world_map.nearest_road(wx, wy, 120)
            v = Vehicle(rx, ry, vtype, float(angle))
            self.vehicles.append(v)

    def _get_nearest_vehicle(self, px, py, max_dist=60):
        best, best_d = None, max_dist
        for v in self.vehicles:
            if v.driver is None and v.active:
                d = v.distance_to(px, py)
                if d < best_d:
                    best_d = d
                    best   = v
        return best

    # ── per-frame update ─────────────────────────────────────────────────────

    def update(self, dt: float, keys):
        self.elapsed += dt

        # Player
        self.player.update(keys, dt, self.world_map, self.vehicles)

        # Vehicles
        for v in self.vehicles:
            if v.driver is None:
                v.free_update(dt, self.world_map)

        # NPCs
        self.npc_system.update(
            dt, self.player.x, self.player.y,
            self.crime.heat, self.world_map)

        # Pursuer vehicles (pursuit vehicles spawn by crime system)
        self.crime.update(dt, self.player, self.regions, self.npc_system)
        self.crime.update_spawn(dt, self.player, self.npc_system, self.world_map)

        # World simulation
        current_region = get_region_at(
            self.regions, self.player.x, self.player.y)
        for r in self.regions:
            r.update(dt, r == current_region)
        self.factions.update(dt, current_region)
        self.economy.update(dt, current_region)

        # Missions
        self.missions.update(
            dt, self.player, self.regions, self.world_map,
            self.economy, self.factions, self.crime)

        # Camera
        self.camera.follow(self.player.x, self.player.y, dt)

        return current_region

    # ── render ───────────────────────────────────────────────────────────────

    def render(self, surface: pygame.Surface, current_region):
        cam_x, cam_y = self.camera.x, self.camera.y

        # World
        surface.fill(C_BG)
        self.world_map.render(surface, cam_x, cam_y)

        # Faction zone tints (subtle overlay)
        self._draw_zone_tints(surface, cam_x, cam_y)

        # Vehicles
        for v in self.vehicles:
            v.render(surface, cam_x, cam_y)

        # NPCs
        self.npc_system.render(surface, cam_x, cam_y)

        # Mission markers
        self.missions.render_markers(
            surface, cam_x, cam_y, self.hud.font_sm(), self.elapsed)

        # Player (on-foot)
        nearest_v = self._get_nearest_vehicle(self.player.x, self.player.y)
        self.player.render(
            surface, cam_x, cam_y, self.hud.font_sm(), nearest_v)

        # HUD
        self.hud.render(
            surface, 0.016, self.player, current_region,
            self.crime, self.missions, self.factions,
            self.economy, self.fps)

        # Minimap
        self.minimap.render(
            surface, self.player, self.vehicles,
            self.npc_system, self.missions.active_missions, self.regions)

    def _draw_zone_tints(self, surface, cam_x, cam_y):
        """Very subtle zone colour overlays (surfaces pre-baked per region)."""
        if not hasattr(self, '_zone_tint_cache'):
            self._zone_tint_cache = {}
        for region in self.regions:
            rw  = int(region.wx1 - region.wx0)
            rh  = int(region.wy1 - region.wy0)
            col = region.dominant_colour()
            key = (region.name, col)
            if key not in self._zone_tint_cache:
                tint = pygame.Surface((rw, rh), pygame.SRCALPHA)
                tint.fill((*col, 6))
                self._zone_tint_cache[key] = tint
            rx = int(region.wx0 - cam_x)
            ry = int(region.wy0 - cam_y)
            surface.blit(self._zone_tint_cache[key], (rx, ry))

    # ── event handling ───────────────────────────────────────────────────────

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_TAB:
                self.hud.toggle_factions()
            if event.key == pygame.K_m:
                # Force-generate a mission
                self.missions.try_generate(
                    self.player.x, self.player.y,
                    self.regions, self.world_map,
                    self.economy, self.factions)
